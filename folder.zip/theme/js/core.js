
$(document).ready(function() {
    console.log('In principio erat Verbum.');
})


